package com.pack.junit5.examples;

import org.junit.platform.suite.api.IncludeTags;
import org.junit.platform.suite.api.SelectPackages;

@SelectPackages("com.pack.junit5.examples")
@IncludeTags("development")
public class DevelopmentTests 
{
}
