package com.pack.junit5.examples.suites;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

import com.pack.junit5.examples.TempDirTests;

@Suite
@SelectClasses(TempDirTests.class)
public class TempDirectoryTestSuite {

}
