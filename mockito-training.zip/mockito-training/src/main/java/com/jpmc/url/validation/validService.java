package com.jpmc.url.validation;

public class validService {

	WebURLValidator webval;
	
	public validService(WebURLValidator webur)
	{
		this.webval=webur;
	}
	public boolean valid(String url)
	{
		
		return webval.isValidURL(url);
	}
}
