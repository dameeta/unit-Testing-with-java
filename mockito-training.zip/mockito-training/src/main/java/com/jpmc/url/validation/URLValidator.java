package com.jpmc.url.validation;

import java.util.List;

public interface URLValidator {
    /**
     * Determines whether a given CharSequence represents a valid URL
     * @param url
     * @return true if its valid
     */
    boolean isValidURL(CharSequence url);

    /**
     * The list of secure protocols that this validator supports
     * @return a list of supported protocols
     */
    List<CharSequence> secureProtocols();
}