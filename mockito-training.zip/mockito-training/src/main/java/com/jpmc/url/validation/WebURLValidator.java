package com.jpmc.url.validation;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class WebURLValidator implements URLValidator {

    /**
     * URL Regex validation pattern.
     */
    public static final Pattern URL_PATTERN = Pattern.compile(
            "^(http:\\/\\/www\\.|https:\\/\\/www\\.|http:\\/\\/|https:\\/\\/|ftp:\\/\\/|ftps:\\/\\/)?[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}(:[0-9]{1,5})?(\\/.*)?$"
    );

    private static final List<CharSequence> SECURE_PROTOCOLS = createSupportedSecureProtocols();

    private static ArrayList<CharSequence>createSupportedSecureProtocols() {
        ArrayList<CharSequence> protocols = new ArrayList<CharSequence>();
        protocols.add("https");
        protocols.add("ftps");
        return protocols;
    }

    /**
     * Validates if the given input is a valid url
     *
     * @param url        The email to validate.
     * @return {@code true} if the input is a valid url. {@code false} otherwise.
     */
    public boolean isValidURL(CharSequence url) {
        return url != null && URL_PATTERN.matcher(url).matches();
    }

    public List<CharSequence> secureProtocols() {
        return SECURE_PROTOCOLS;
    }

}
