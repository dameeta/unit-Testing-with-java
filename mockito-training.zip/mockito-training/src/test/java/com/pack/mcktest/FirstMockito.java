package com.pack.mcktest;

import static org.junit.Assert.*;

import org.junit.Test;

public class FirstMockito {

	@Test
	public void test() {

	assertTrue(true);
	}

}
