package com.pack.mcktest;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;
import com.jpmc.url.validation.WebURLValidator;
import com.jpmc.url.validation.validService;

public class WebUrlValidatorImplTest {
	
	
	validService service=null;
	WebURLValidator srv=mock(WebURLValidator.class);
	@Before
	public void setUp()
	{
		service=new validService(srv);
	}
	@Test
	public void testValidUrl()
	{
		//when(srv.isValidURL("https://github.com/vadimuWu/pre_vado")).thenReturn(true);
		assertEquals(false, service.valid("https://github.com/vadimuWu/pre_vado"));
		//verify(srv.isValidURL("https://github.com/vadimuWu/pre_vado"));
	}
	
	
}
	
	
