package demosuitetest.junit;
import static org.junit.Assert.assertEquals;				

import org.junit.Test;

import com.jpmc.url.validation.JUnitMessage;		

public class SampleSuiteTest1 {				

    public String str = "Tom";							

    JUnitMessage jm = new JUnitMessage(str);							
    	
    @Test(expected = ArithmeticException.class)					
    public void DemoTest1() {					

        System.out.println("SampleTest1 Message is printing ");					
        jm.printMessage();			

    }		

    @Test		
    public void DemoTest2() {					
        str = "Welcome" + str;							
        System.out.println("SampleTest2 Welcome Message is printing ");					
        assertEquals(str, jm.printHiMessage());				
        System.out.println(" SampleSuiteTest2 is successful " + str);							
    }		
}	
