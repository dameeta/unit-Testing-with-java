package demosuitetest.junit;

import org.junit.Assert;		
import org.junit.Test;		

public class SampleSuiteTest2 {				
   	

    @Test		
    public void createAndSetName() {					
        		

        String expected = "A";					
        String actual = "A";					

        Assert.assertEquals(expected, actual);					
        System.out.println("SampleSuiteTest1 is successful " + actual);							
    }		

}
