package demosuitetest.junit;
import org.junit.runner.RunWith;		
import org.junit.runners.Suite;		

@RunWith(Suite.class)				
@Suite.SuiteClasses({				
  SampleSuiteTest1.class,
  SampleSuiteTest2.class,  			
})		

public class DemoTest {				
// This class will be empty. It will be holder for the above annotations		


}
